<?php

header('location:reviewrating.php?success=yes&#support');
?>