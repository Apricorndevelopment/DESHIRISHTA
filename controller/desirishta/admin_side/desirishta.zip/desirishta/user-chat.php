<?php
include 'header.php';
include 'config.php';
?>
        <!-- LOGIN -->
        <section>
            <div class="db">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-lg-3">
                            <?php
                            include 'user-sidebar.php';
                            ?>
                        </div>
                        <div class="col-md-8 col-lg-9">
                            <div class="row">
                                <div class="col-md-12 db-sec-com">
                                    <h2 class="db-tit">Chat list</h2>
                                    <div class="db-pro-stat">
                                        <div class="db-chat">
                                            <ul>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/1.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Ashley emyy</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time new">
                                                            <span class="timer">9:00 PM</span>
                                                            <span class="cont">3</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/16.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Julia Ann</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time new">
                                                            <span class="timer">9:00 PM</span>
                                                            <span class="cont">2</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/12.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Elizabeth Taylor</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time new">
                                                            <span class="timer">8:00 PM</span>
                                                            <span class="cont">3</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/13.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Angelina Jolie</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time">
                                                            <span class="timer">3:00 PM</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/14.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Olivia mia</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time">
                                                            <span class="timer">5:00 PM</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/1.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Ashley emyy</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time new">
                                                            <span class="timer">9:00 PM</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/16.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Julia Ann</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time new">
                                                            <span class="timer">9:00 PM</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/12.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Elizabeth Taylor</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time new">
                                                            <span class="timer">8:00 PM</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/13.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Angelina Jolie</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time">
                                                            <span class="timer">3:00 PM</span>
                                                        </div>
                                                    </div>
                                                </li>
                                                <li class="db-chat-trig">
                                                    <div class="db-chat-pro"> <img src="images/profiles/14.jpg" alt=""> </div>
                                                    <div class="db-chat-bio">
                                                        <h5>Olivia mia</h5> 
                                                        <span>Hi Anna, How are you?</span> 
                                                    </div>
                                                    <div class="db-chat-info">
                                                        <div class="time">
                                                            <span class="timer">5:00 PM</span>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END -->
<?php
include 'footer.php';
?>