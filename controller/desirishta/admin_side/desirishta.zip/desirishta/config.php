<?php
error_reporting(0); // Sab errors aur warnings band
ini_set('display_errors', 0); // Browser me errors show na ho
date_default_timezone_set('Asia/Kolkata');
$con = mysqli_connect('localhost','root','','shangril_desirishta');

?>