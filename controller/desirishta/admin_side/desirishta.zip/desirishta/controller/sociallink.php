<?php
include 'header.php';
include 'config.php';

$sql = "select * from sociallinks where id = '1'";
$result = mysqli_query($con,$sql);
$row = mysqli_fetch_assoc($result);
?>

    <!-- BEGIN: Content-->
    <div class="app-content content ">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">Social Links</h2>
                            <div class="breadcrumb-wrapper">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.html">Home</a>
                                    </li>
                                    <li class="breadcrumb-item active"><a href="#">Social Links</a>
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
                    <div class="form-group breadcrumb-right">
                        <div class="dropdown">
                            <button class="btn-icon btn btn-primary btn-round btn-sm dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i data-feather="grid"></i></button>
                            <div class="dropdown-menu dropdown-menu-right"><a class="dropdown-item" href="app-todo.html"><i class="mr-1" data-feather="check-square"></i><span class="align-middle">Todo</span></a><a class="dropdown-item" href="app-chat.html"><i class="mr-1" data-feather="message-square"></i><span class="align-middle">Chat</span></a><a class="dropdown-item" href="app-email.html"><i class="mr-1" data-feather="mail"></i><span class="align-middle">Email</span></a><a class="dropdown-item" href="app-calendar.html"><i class="mr-1" data-feather="calendar"></i><span class="align-middle">Calendar</span></a></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <!-- Basic multiple Column Form section start -->
                <section id="multiple-column-form">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Add Social Link</h4>
                                </div>
                                <div class="card-body">
                                    <?php
                                    if($_GET['update'] == 'success')
                                    {
                                    ?>
                                        <p class="text-center text-success">Updated Successfully</p>
                                    <?php
                                    }
                                    ?>
                                    <form class="form" action="update-sociallink.php" method="post">
                                        <div class="row">
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="first-name-column"><b>Facebook</b></label>
                                                    <div class="input-group input-group-merge">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i data-feather="facebook"></i></span>
                                                        </div>
                                                        <input type="text" id="first-name-icon" class="form-control" name="facebook" value="<?php echo $row['facebook']; ?>" placeholder="Facebook"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="last-name-column"><b>Twitter</b></label>
                                                    <div class="input-group input-group-merge">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i data-feather="twitter"></i></span>
                                                        </div>
                                                        <input type="text" id="first-name-icon" class="form-control" name="twitter" value="<?php echo $row['twitter']; ?>" placeholder="Twitter" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="last-name-column"><b>Linkedin</b></label>
                                                    <div class="input-group input-group-merge">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i data-feather="linkedin"></i></span>
                                                        </div>
                                                        <input type="text" id="first-name-icon" class="form-control" name="linkedin" value="<?php echo $row['linkedin']; ?>" placeholder="Linkedin" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="last-name-column"><b>Youtube</b></label>
                                                    <div class="input-group input-group-merge">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i data-feather="file-text"></i></span>
                                                        </div>
                                                        <input type="text" id="first-name-icon" class="form-control" name="youtube" value="<?php echo $row['pinterest']; ?>" placeholder="Pinterest" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6 col-12">
                                                <div class="form-group">
                                                    <label for="last-name-column"><b>Instagram</b></label>
                                                    <div class="input-group input-group-merge">
                                                        <div class="input-group-prepend">
                                                            <span class="input-group-text"><i data-feather="instagram"></i></span>
                                                        </div>
                                                        <input type="text" id="first-name-icon" class="form-control" name="instagram" value="<?php echo $row['instagram']; ?>" placeholder="Instagram" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12 text-center mt-2 mb-2">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Basic Floating Label Form section end -->

            </div>
        </div>
    </div>
    <!-- END: Content-->

<?php
include 'footer.php';   
?>