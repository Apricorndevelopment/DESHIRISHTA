<?php
include 'header.php';

?>

    <!-- PRICING PLANS -->
    <section>
        <div class="plans-ban">
            <div class="container">
                <div class="row">
                    <span class="pri">Pricing</span>
                    <h1>Get Started <br> Pick your Plan Now</h1>
                    <p>Leading Matrimony & Genuine Matchmaking Service At An Affordable Price</p>
                    <!--<span class="nocre">No credit card required</span>-->
                </div>
            </div>
        </div>
    </section>
    <!-- END -->

    <!-- PRICING PLANS -->
    <section>
        <div class="plans-main">
            <div class="container">
                <div class="row">
                    <ul>
                        <li>
                            <div class="pri-box">
                                <h2>Free</h2>
                                <a href="sign-up.html" class="cta">Coming Soon</a>
                                <span class="pri-cou"><b>₹ 0</b></span>
                                <ol>
                                    <li><i class="fa fa-check" aria-hidden="true"></i> Unlimited profile views</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>View 5 contact details/ day</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>Contacts view validity - 14 days</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>Unlimited WhatsApp Profile Sharing</li>
                                </ol>
                            </div>
                        </li>
                        <li>
                            <div class="pri-box pri-box-pop">
                                <span class="pop-pln">Most popular plan</span>
                                <h2>Gold</h2>
                                <a href="sign-up.html" class="cta">Coming Soon</a>
                                <span class="pri-cou"><b>₹ -</b></span>
                                <ol>
                                    <li><i class="fa fa-check" aria-hidden="true"></i> Unlimited Profile views</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>View 15 contact details / day</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>Contacts view validity – 30 days</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>Unlimited WhatsApp Profile Sharing</li>
                                </ol>
                            </div>
                        </li>
                        <li>
                            <div class="pri-box">
                                <h2>Platinum</h2>
                                <a href="sign-up.html" class="cta">Coming Soon</a>
                                <span class="pri-cou"><b>₹ -</b></span>
                                <ol>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>Unlimited Profile views</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>View 25 contact details / day </li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>Contacts view validity – 60 days</li>
                                    <li><i class="fa fa-check" aria-hidden="true"></i>Unlimited WhatsApp Profile Sharing</li>
                                </ol>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- END -->

 <?php
 include 'footer.php';
 ?>