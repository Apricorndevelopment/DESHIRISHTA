<?php
include 'config.php';

//Basic info

createby
fullname
dob
marital
height
weight
physical
religion

?>