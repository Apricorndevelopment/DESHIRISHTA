<?php
include 'header.php';
?>
    <!-- LOGIN -->
    <section>
        <div class="login">
            <div class="container">
                <div class="row">

                    <div class="inn">
                        <div class="lhs">
                            <div class="tit">
                                <h2>Now <b>Find <br> your life partner</b> Easy and fast.</h2>
                            </div>
                            <div class="im"> 
                                <img src="images/login-couple.png" alt="">
                            </div>
                            <div class="log-bg">&nbsp;</div>
                        </div>
                        <div class="rhs"> 
                            <div>
                                <!--<div>
                                    <a href="forgot-newpassword.php"><i class="fa fa-arrow-left text-left leftarrow"></i></a>
                                    <a href="login.php"><i class="fa fa-close text-right closecross"></i></a>
                                </div>-->
                                <div class="form-tit">
                                    <center>
                                        <img src="images/two-step-verification.gif" style="width:35%; text-align:center;">
                                    </center>
                                    <h1 class="text-center text-success">Password Updated Successfully</h1>
                                </div>
                                <div class="form-login">
                                    <a href="login.php" class="btn btn-primary">Go to Sign In</a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- END -->

<?php
include 'footer.php';
?>
